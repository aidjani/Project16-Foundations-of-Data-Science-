import pandas as pd
import seaborn as sns
import numpy as np
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import scipy.stats as sts
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import roc_curve, confusion_matrix, auc
from sklearn.ensemble import RandomForestClassifier
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score
import os
from sklearn.cluster import DBSCAN
import pandas as pd
from scipy.stats import chi2_contingency

print("*******************Import Data*******************")
#Import data
data = pd.read_csv("../data/heart_2020_cleaned.csv")

print("*******************Cleaning the data*******************")
#Remove SleepTime 
data = data.drop('SleepTime', axis=1)


#change category names of diabetes column
data['Diabetic'] = data['Diabetic'].replace('No, borderline diabetes', 'Borderline diabetes')
data['Diabetic'] = data['Diabetic'].replace('Yes (during pregnancy)', 'During pregnancy')


print("*******************Data Type Inspection*******************")
#inspect the data types
num_cols = []
cat_cols = []
#print(data.dtypes) #data types are float64 and object

#divide BMI into 4 categories (with WHO recommendations)
for i in range(len(data)):
    if data.loc[i, 'BMI'] < 18.5:
        data.loc[i, 'BMI'] = 'underweight'
    elif 18.5 <= data.loc[i, 'BMI'] <= 24.9:
        data.loc[i, 'BMI'] = 'normal'
    elif 25 <= data.loc[i, 'BMI'] <= 29.9:
        data.loc[i, 'BMI'] = 'overweight'
    else:
        data.loc[i, 'BMI'] = 'obesity'


columns = data.columns.values.tolist() #list of all column names

#age and general health should be numerical and not categorical data!
for col in columns:
    if data[col].dtype == "float64":
       num_cols.append(col) 
    else:
        cat_cols.append(col)


#physical health, mental health and sleep time can be stored as integers rather than floats
data['PhysicalHealth'] = data['PhysicalHealth'].astype("int32") 
data['MentalHealth'] = data['MentalHealth'].astype("int32")
#data['SleepTime'] = data['SleepTime'].astype("int32") removed sleeptime 
for col in cat_cols:    
    print("Categories in ", col, ": ", data[col].unique()) #nr of categories the categorical variable has
    if col != "Sex" and data[col].nunique() == 2: #convert all binary categories to booleans except sex
        data[col] = data[col].map({'Yes': True, 'No': False})



print("*******************Implementing a balanced dataset*******************")
# Split the data into positive and negative classes
positive_data = data[data['HeartDisease'] == True]
negative_data = data[data['HeartDisease'] == False]

# Determine the number of instances in the positive class
positive_count = len(positive_data)

# Sample the same number of instances from the negative class using stratified sampling
negative_sampled = negative_data.groupby('HeartDisease').apply(lambda x: x.sample(n=positive_count))

# Combine the sampled positive and negative instances
balanced_data = pd.concat([positive_data, negative_sampled])

# Shuffle the balanced dataset
balanced_data = balanced_data.sample(frac=1).reset_index(drop=True)


# perform one-hot encoding
print("*******************One-Hot Encoding*******************")
data_encoded = pd.get_dummies(data, columns=cat_cols, drop_first=False) # encoded dataset for imbalanced data
data_encoded_balanced = pd.get_dummies(balanced_data, columns=cat_cols, drop_first=False) # encoded dataset for balanced data


print("*******************Feature Selection*******************")
data_selected = data_encoded.drop(['MentalHealth', 'BMI_normal', 'BMI_obesity', 'BMI_overweight', 'BMI_underweight',
       'AlcoholDrinking_False', 'AlcoholDrinking_True', 'DiffWalking_False', 'DiffWalking_True',
       'Race_American Indian/Alaskan Native', 'Race_Asian', 'Race_Black', 'Race_Hispanic', 'Race_Other', 'Race_White',
       'GenHealth_Excellent', 'GenHealth_Fair','GenHealth_Good', 'GenHealth_Poor', 'GenHealth_Very good',
       'Asthma_False', 'Asthma_True'], axis=1)


print("*******************Defining X and y*******************")
y = data['HeartDisease'].replace({'True': 1, 'False': 0}).astype(int) # reconverted to integer from bool, y for imbalanced dataset with and without feature selection
X_encoded = data_encoded.drop(['HeartDisease_False', 'HeartDisease_True'], axis=1) # X for without feature selection
X_encoded_selected = data_selected.drop(['HeartDisease_False', 'HeartDisease_True'], axis=1) # X for with feature selection

X_encoded_balanced  = data_encoded_balanced.drop(['HeartDisease_False', 'HeartDisease_True'], axis=1) # without feature selection
y_balanced = balanced_data['HeartDisease'].replace({'True': 1, 'False': 0}).astype(int)  # reconverted to integer from bool


'''################################################################## Logistic Regression & Random Forest ##################################################################'''

''' get confusion matrix of a classifier yielding predictions (y_pred) for the true class labels (y) '''
def get_confusion_matrix(y, y_pred):
   
    # true/false pos/neg.
    tp = 0 # tp = true positive
    fp = 0 # fp = false positive
    tn = 0 # tn = true negative
    fn = 0 # fn = false negative

    # summarize positive and negative classes
    for i in range (len(y)):
        if y[i] == 1 and y_pred[i] == 1:
            tp += 1                        
        elif y[i] == 0 and y_pred[i] == 1:
            fp += 1                         
        elif y[i] == 0 and y_pred[i] == 0:
            tn += 1
        elif y[i] == 1 and y_pred[i] == 0:
            fn += 1
    return tn, fp, fn, tp

''' compute the evaltuation metrics for the provided classifier (given: true labels, input features) '''
def evaluation_metrics(clf, y, X, ax,legend_entry='my legendEntry'):

    # calculate labels prediction
    y_test_pred = clf.predict(X)
    
    # convert y into an array-> same dimension as y_test_pred (=> needed for def get_confusion_matrix)
    y = y.values

    # Calculate the confusion matrix
    tn, fp, fn, tp = get_confusion_matrix(y, y_test_pred)

    # Ensurance to get the correct confusion matrix
    tn_sk, fp_sk, fn_sk, tp_sk = confusion_matrix(y, y_test_pred).ravel()
    if np.sum([np.abs(tp-tp_sk) + np.abs(tn-tn_sk) + np.abs(fp-fp_sk) + np.abs(fn-fn_sk)]) >0:
        print(' Confusion matrix failed. ')
        tn = tn_sk
        tp = tp_sk
        fn = fn_sk
        fp = fp_sk
    else:
        print(' Confusion matrix implementation was successful. ')

    # Calculate evaluation metrics
    precision   = tp / (tp + fp)
    specificity = tn / (tn + fp)
    recall      = tp / (tp + fn)
    f1          = tp/(tp + 0.5*(fp+fn))

    # Get the roc curve
    y_test_predict_proba  = clf.predict_proba(X)[:, 1]
    fp_rates, tp_rates, _ = roc_curve(y, y_test_predict_proba)

    # Calculate the area under the roc curve (with auc)
    roc_auc = auc(fp_rates, tp_rates)

    # Plot on the provided axis
    ax.step(fp_rates, tp_rates, where='post', label=legend_entry + ' (AUC = {:.2f})'.format(roc_auc))

    return [precision, recall, specificity, f1, roc_auc]

''' performace metrics for LR and RF'''
def performace_metrics (X,y, fs, imagename_roc_curve,filename_table_metrics, imagename_importance_normalized_coefficient_LR, imagename_importance_normalized_coefficient_RF, filename_table_with_coefficients_LR, filename_table_with_coefficients_RF , filename_table_with_performance):

    data_encoded_performance = pd.DataFrame(columns = ['fold','clf','precision','recall','specificity','F1','roc_auc']) # Prepare performance overview data frame
    data_encoded_LR_normcoef = pd.DataFrame(index = X.columns, columns = np.arange(n_splits)) 
    data_encoded_RF_normcoef = pd.DataFrame(index = X.columns, columns = np.arange(n_splits))


    fold = 0
    fig,axs = plt.subplots(1,2, figsize=(9, 4))

    for train_index, test_index in skf.split(X, y): 

        # Subsets for training and testing
        X_test  = X.iloc[test_index]
        y_test  = y.iloc[test_index]
        X_train = X.iloc[train_index]
        y_train = y.iloc[train_index]

        # Standardize numerical features (with training set statistics)
        sc = StandardScaler()
        X_train_sc = sc.fit_transform(X_train)
        X_test_sc  = sc.transform(X_test)

        # Logistic Regression
        LR_clf = LogisticRegression(random_state=1)
        LR_clf.fit(X_train_sc, y_train)

        # Random Forest
        RF_clf = RandomForestClassifier(random_state=1)
        RF_clf.fit(X_train_sc, y_train)


        # Get all features that contribute to classification
        # Logistigc Regression: get normalized feature coeffients
        data_encoded_this_LR_coefs = pd.DataFrame(zip(X_train.columns, np.transpose(LR_clf.coef_[0])), columns=['features', 'coef'])
        data_encoded_LR_normcoef.isetitem(fold, data_encoded_this_LR_coefs['coef'].values / data_encoded_this_LR_coefs['coef'].abs().sum())

        # Random Forest: get feature importance
        feature_importances_RF = pd.DataFrame(zip(X_train.columns, RF_clf.feature_importances_), columns=['features', 'importance'])
        data_encoded_RF_normcoef.isetitem(fold, feature_importances_RF['importance'].values / feature_importances_RF['importance'].abs().sum())


        # Evaluate the classifiers Logistic Regression, Random Forest
        eval_metrics_LR = evaluation_metrics(LR_clf, y_test, X_test_sc, axs[0], legend_entry=str(fold)) # evaluation metrics for Logistic Regression 
        data_encoded_performance.loc[len(data_encoded_performance)-1,:] = [fold,'LR']+eval_metrics_LR # add the evaluation metrics of LR to data_encoded_performance after each fold
        eval_metrics_RF = evaluation_metrics(RF_clf, y_test, X_test_sc, axs[1], legend_entry=str(fold)) # evaluation metrics for Random Forest 
        data_encoded_performance.loc[len(data_encoded_performance)-1, :] = [fold, 'RF'] + eval_metrics_RF # add the evaluation metrics of RF to data_encoded_performance after each fold

        # increase counter for folds
        fold += 1

    ''' make ROC curve'''
    #for Random Forest and Logistic Regression with and without feature selection on imbalanced dataset
    # + Logistic Regression and Random Forest without feature selection on balanced dataset  
    model_names = ['LR', 'RF']  #Logistic Regression, Random Forest
    for i, ax in enumerate(axs):
        ax.set_xlabel('False positive rate (FPR)')
        ax.set_ylabel('True Positive Rate (TPR)')
        ax.plot([0, 1], [0, 1], color='r', linestyle='--', label='random\nclassifier')
        ax.set_title('ROC Curve for ' + model_names[i] + ' ' + fs) # model_names: Logistic Regression or Random Forest ; fs: without feature selection, with feature selection, balanced dataset
        ax.legend(title='Fold',loc='lower right')
        ax.grid(True)
    plt.tight_layout()
    plt.savefig(imagename_roc_curve)


    # group performance metrics by classifier type
    df_by_clf = data_encoded_performance.groupby('clf')

    # table with mean and standard deviation for each metric and classifier type
    mean_prec = df_by_clf['precision'].mean() # precision 
    std_prec = df_by_clf['precision'].std()
    mean_recall = df_by_clf['recall'].mean() # recall
    std_recall = df_by_clf['recall'].std()
    mean_spec = df_by_clf['specificity'].mean() # specificity
    std_spec = df_by_clf['specificity'].std()
    mean_F1 = df_by_clf['F1'].mean() # F1 score
    std_F1 = df_by_clf['F1'].std()
    mean_roc_auc = df_by_clf['roc_auc'].mean() # ROC AUC
    std_roc_auc = df_by_clf['roc_auc'].std()

    # create a table with the mean metrics after 5-fold cross validation of Logistic Regression and Random Forest
    table_data = {'Classifier': ['Logistic Regression', 'Random Forest'],
                'Precision (mean ± std)': [f"{mean_prec['LR']:.3f} ± {std_prec['LR']:.3f}", f"{mean_prec['RF']:.3f} ± {std_prec['RF']:.3f}"],
                'Recall (mean ± std)': [f"{mean_recall['LR']:.3f} ± {std_recall['LR']:.3f}", f"{mean_recall['RF']:.3f} ± {std_recall['RF']:.3f}"],
                'Specificity (mean ± std)': [f"{mean_spec['LR']:.3f} ± {std_spec['LR']:.3f}", f"{mean_spec['RF']:.3f} ± {std_spec['RF']:.3f}"],
                'F1 score (mean ± std)': [f"{mean_F1['LR']:.3f} ± {std_F1['LR']:.3f}", f"{mean_F1['RF']:.3f} ± {std_F1['RF']:.3f}"],
                'ROC AUC score (mean ± std)': [f"{mean_roc_auc['LR']:.3f} ± {std_roc_auc['LR']:.3f}", f"{mean_roc_auc['RF']:.3f} ± {std_roc_auc['RF']:.3f}"]}

    table = pd.DataFrame(table_data)
    table.to_csv(filename_table_metrics, index=False)

    '''Get feature importance for Logistc Regression and Random Forest '''
    # Logist Regression
    data_encoded_LR_normcoef['importance_mean'] = data_encoded_LR_normcoef.mean(axis =1)
    data_encoded_LR_normcoef['importance_std']  = data_encoded_LR_normcoef.std(axis =1)
    data_encoded_LR_normcoef['importance_abs_mean'] = data_encoded_LR_normcoef.abs().mean(axis =1)
    data_encoded_LR_normcoef.sort_values('importance_abs_mean', inplace = True, ascending=False)

    data_encoded_LR_normcoef['mean'] = data_encoded_LR_normcoef.mean(axis=1) # mean of normalized coefficients 
    data_encoded_LR_normcoef_sorted = data_encoded_LR_normcoef.sort_values(by='mean', ascending=False) # sort coefficients by mean 


    # Visualised feature importance with Logistic Regression
    fig, ax = plt.subplots(figsize=(9,9)) # visualization of each feature by normalized coefficient
    colors = ['g' if val < 0 else 'r' for val in data_encoded_LR_normcoef_sorted['mean']]
    data_encoded_LR_normcoef_sorted.plot(kind='barh', y='mean', xerr=data_encoded_LR_normcoef_sorted.std(axis=1), legend=False, ax=ax, color=colors, zorder=10) # give the values in the plot
    for y in range(len(data_encoded_LR_normcoef_sorted)):
        ax.axhline(y=y, color='lightgrey', linestyle='--', zorder=0) 
    ax.set_title(' Feature importance | Logistic Regression | ' + fs) # Logistic Regression
    ax.set_xlabel('Normalized Coefficient')
    ax.set_ylabel('Features')
    positive_patch = mpatches.Patch(color='red', label='Positive values')
    negative_patch = mpatches.Patch(color='green', label='Negative values')
    ax.legend(handles=[positive_patch, negative_patch], loc = 'lower left', )
    plt.tight_layout()
    plt.savefig(imagename_importance_normalized_coefficient_LR)

    # Randm Forest
    data_encoded_RF_normcoef['importance_mean'] = data_encoded_RF_normcoef.mean(axis =1)
    data_encoded_RF_normcoef['importance_std']  = data_encoded_RF_normcoef.std(axis =1)
    data_encoded_RF_normcoef['importance_abs_mean'] = data_encoded_RF_normcoef.abs().mean(axis =1)
    data_encoded_RF_normcoef.sort_values('importance_abs_mean', inplace = True, ascending=False)

    data_encoded_RF_normcoef['mean'] = data_encoded_RF_normcoef.mean(axis=1) # mean of normalized coefficients 
    data_encoded_RF_normcoef_sorted = data_encoded_RF_normcoef.sort_values(by='mean', ascending=False) # sort coefficients by mean 

    # Visualised feature importance with Random Forest
    fig, ax = plt.subplots(figsize=(9,9)) # visualization of each feature by normalized coefficient
    data_encoded_RF_normcoef_sorted.plot(kind='barh', y='mean', xerr=data_encoded_RF_normcoef_sorted.std(axis=1), legend=False, ax=ax) # give the values in the plot
    ax.set_title(' Feature importance | Random Forest | ' + fs) # Random Forest
    ax.set_xlabel('Feature Importance')
    ax.set_ylabel('Features')
    plt.tight_layout()
    plt.savefig(imagename_importance_normalized_coefficient_RF)


    #sort the coefficients/feature importance (not normalized) to later add those to a table
    data_encoded_this_LR_coefs = data_encoded_this_LR_coefs.sort_values(by='coef', ascending=False) 
    
    # save normalized 
    data_encoded_this_LR_coefs.to_csv(filename_table_with_coefficients_LR, index=False)
    
    # sort the feature importance for RF
    feature_importances_RF = feature_importances_RF.sort_values(by='importance', ascending=False)
    # save feature importance table to csv
    feature_importances_RF.to_csv(filename_table_with_coefficients_RF, index=False)

    # save performance table to csv
    data_encoded_performance.to_csv(filename_table_with_performance, index=False)


''' prepare the splits (perform a 5-fold crossvalidation)'''
n_splits = 5 # number of folds
skf = StratifiedKFold(n_splits=n_splits)

'''Run performance for Logistic Regression and Random Forest'''
# without feature selection
performace_metrics (X_encoded, y, 'no feature selection', '../output/LR_RF/roc_curve/without_features_selection','../output/LR_RF/table_metrics/without_features_selection.csv', '../output/LR_RF/importance_normalized_coefficient/LR_without_features_selection', '../output/LR_RF/importance_normalized_coefficient/RF_without_features_selection', '../output/LR_RF/table_with_coefficients/LR_without_features_selection.csv',  '../output/LR_RF/table_with_coefficients/RF_without_features_selection.csv',  '../output/LR_RF/table_with_performance/without_features_selection.csv')
# with feature selection
performace_metrics (X_encoded_selected, y, 'with feature selection', '../output/LR_RF/roc_curve/with_features_selection','../output/LR_RF/table_metrics/with_features_selection.csv', '../output/LR_RF/importance_normalized_coefficient/LR_with_features_selection', '../output/LR_RF/importance_normalized_coefficient/RF_with_features_selection', '../output/LR_RF/table_with_coefficients/LR_with_features_selection.csv', '../output/LR_RF/table_with_coefficients/RF_with_features_selection.csv', '../output/LR_RF/table_with_performance/with_features_selection.csv')
# with balanced data set
performace_metrics (X_encoded_balanced, y_balanced, 'balanced', '../output/LR_RF/roc_curve/balanced','../output/LR_RF/table_metrics/balanced.csv', '../output/LR_RF/importance_normalized_coefficient/LR_balanced', '../output/LR_RF/importance_normalized_coefficient/RF_balanced', '../output/LR_RF/table_with_coefficients/LR_balanced.csv', '../output/LR_RF/table_with_coefficients/RF_balanced.csv', '../output/LR_RF/table_with_performance/balanced.csv')
