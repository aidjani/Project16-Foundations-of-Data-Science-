import pandas as pd
import seaborn as sns
import numpy as np
from scipy.spatial.distance import cdist
import matplotlib.pyplot as plt
import scipy.stats as sts
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import roc_curve, confusion_matrix, auc
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score
import os
from sklearn.cluster import DBSCAN
import pandas as pd
from scipy.stats import chi2_contingency
#Version martina 24.05.23, 22:30 Uhr
#code seems to compile but takes like 20 min until it computes all folds.
#Import data
data = pd.read_csv("../data/heart_2020_cleaned.csv")

#Remove SleepTime 
data = data.drop('SleepTime', axis=1)

#Inspect the data
print(data.head())
print("The dataset has ", data.shape[0], "rows ", data.shape[1], "columns and", data.shape[0]*data.shape[1], "entries.")


print("******************Description of the data***************************")
print(data.describe())


#Unique Values 
for col in data.columns:
    unique_values = data[col].unique()
    unique_count = len(unique_values)
    print("Sum of unique values in", col, ":", unique_count)
columns = data.columns.values.tolist() #list of all column names
#print(columns)
#change category names of diabetes column
data['Diabetic'] = data['Diabetic'].replace('No, borderline diabetes', 'Borderline diabetes')
data['Diabetic'] = data['Diabetic'].replace('Yes (during pregnancy)', 'During pregnancy')
print("*******************Cleaning the data*******************")
#data = data.drop(data[data['SleepTime'] > 20].index) #based on research, it is not possible to sleep more than 20 h per night
print(data.isna().sum()) #no missing data

print("*******************Data Type Inspection*******************")

#inspect the data types
num_cols = []
cat_cols = []
print(data.dtypes) #data types are float64 and object

#divide BMI into 4 categories (with WHO recommendations)
for i in range(len(data)):
    if data.loc[i, 'BMI'] < 18.5:
        data.loc[i, 'BMI'] = 'underweight'
    elif 18.5 <= data.loc[i, 'BMI'] <= 24.9:
        data.loc[i, 'BMI'] = 'normal'
    elif 25 <= data.loc[i, 'BMI'] <= 29.9:
        data.loc[i, 'BMI'] = 'overweight'
    else:
        data.loc[i, 'BMI'] = 'obesity'


#age and general health should be numerical and not categorical data!
for col in columns:
    if data[col].dtype == "float64":
       num_cols.append(col) 
    else:
        cat_cols.append(col)

#count gender imbalance
print(data['Sex'].value_counts())

#count racial imbalance
print(data['Race'].value_counts())
        


print(num_cols)
print(cat_cols)
#physical health, mental health and sleep time can be stored as integers rather than floats
data['PhysicalHealth'] = data['PhysicalHealth'].astype("int32") 
data['MentalHealth'] = data['MentalHealth'].astype("int32")
#data['SleepTime'] = data['SleepTime'].astype("int32") removed sleeptime 
for col in cat_cols:    
    print("Categories in ", col, ": ", data[col].unique()) #nr of categories the categorical variable has
    if col != "Sex" and data[col].nunique() == 2: #convert all binary categories to booleans except sex
        data[col] = data[col].map({'Yes': True, 'No': False})

#sort the age categories by age
age_categories = data['AgeCategory'].unique()
age_categories.sort()
print(age_categories)

print("*******************Feature Selection*******************")
#feature selection
data_selected = data.drop(["DiffWalking", "GenHealth", "Asthma", "BMI", "AlcoholDrinking", "Race", "MentalHealth"], axis=1)
print(data_selected.head())



#KNN Classification

print("*******************K-Nearest Neighbour*******************")

def get_confusion_matrix(y,y_pred):
 # true/false pos/neg.
    tp = 0
    fp = 0
    tn = 0
    fn = 0

    # count tp, fp, fn, fp
    
    for i in range(len(y)):
        if y[i] ==1 and y_pred[i] == 1:
            tp += 1
        elif y[i] ==1 and y_pred[i] == 0:
            fn += 1
        elif  y[i] ==0 and y_pred[i] == 0:
            tn += 1
        else:
            fp += 1
    return tn, fp, fn, tp

def evaluation_metrics(clf, y, X, ax,legend_entry='my legendEntry'):
    
    
    # Get the label predictions
    y_test_pred = clf.predict(X)

    y = y.values
   
    # Calculate the confusion matrix from the predicted and true labels 
    tn, fp, fn, tp = get_confusion_matrix(y, y_test_pred)    

    precision   = tp / (tp + fp)
    specificity = tn / (tn + fp)
    accuracy    = (tp + tn) / (tp + fp + tn + fn)
    recall      = tp / (tp + fn)
    f1          = tp/(tp + 0.5*(fp+fn))

    # Get the roc curve using a sklearn function
    y_test_predict_proba  = clf.predict_proba(X)[:, 1]
    fp_rates, tp_rates, _ = roc_curve(y, y_test_predict_proba)

    # Calculate the area under the roc curve using a sklearn function
    roc_auc = auc(fp_rates, tp_rates)

    # Plot on the provided axis
    
    
    ax.plot(fp_rates, tp_rates, label=legend_entry + ' (AUC = {:.2f})'.format(roc_auc))    

    return [accuracy,precision,recall,specificity,f1, roc_auc]

def add_identity(axes, *line_args, **line_kwargs):
    identity, = axes.plot([], [], *line_args, **line_kwargs)
    def callback(axes):
        low_x, high_x = axes.get_xlim()
        low_y, high_y = axes.get_ylim()
        low = max(low_x, low_y)
        high = min(high_x, high_y)
        identity.set_data([low, high], [low, high])
    callback(axes)
    axes.callbacks.connect('xlim_changed', callback)
    axes.callbacks.connect('ylim_changed', callback)
    return axes
#perform one-hot encoding on the full dataset
print("*******************KNN without Feature Selection*******************")
feature_selection = False
print("*******************One-Hot Encoding*******************")

#without feature selection
y = data['HeartDisease'].replace({'True': 1, 'False': 0}).astype(int) #reconverted to integer from bool. 
X_encoded = data.drop('HeartDisease', axis=1)
cat_cols.remove('HeartDisease')
'''
#add this part and change line 196 and 199 respectively to run the code for feature selection
#with feature selection
feature_selection = True
y = data_selected['HeartDisease'].replace({'True': 1, 'False': 0}).astype(int) #reconverted to integer from bool. MAYBE DO NOT CONVERT TO BOOL IN THE DATA PREPROCESSING
X_encoded = data_selected.drop('HeartDisease', axis=1)
cat_cols_selected = ['Smoking', 'Stroke', 'Sex', 'AgeCategory', 'Diabetic', 'PhysicalActivity', 'KidneyDisease', 'SkinCancer']
num_cols_selected = ['PhysicalHealth']
'''
for col in cat_cols: #change for FS
    X_encoded[col] = X_encoded[col].replace({'True': 1, 'False': 0})

X_encoded = pd.get_dummies(X_encoded, columns=cat_cols, drop_first=True) #change for FS
X_encoded_sampled = X_encoded.sample(frac=0.1, random_state=42)
y_sampled = y.sample(frac=0.1, random_state=42) #use 10 % of dataset --> 31979 samples

num_cols
#5-fold crossvalidation
n_splits = 5
df_performance = pd.DataFrame(columns = ['clf', 'fold','accuracy','precision','recall','specificity','F1','roc_auc'])
df_KNN_normcoef = pd.DataFrame(index = X_encoded_sampled.columns, columns = np.arange(n_splits)) 
fold = 0
fig,axs = plt.subplots(1,2,figsize=(9, 4))
skf = StratifiedKFold(n_splits)


X_train, X_test, y_train, y_test = train_test_split(X_encoded_sampled, y_sampled, test_size=0.2)

#k is a hyperparameter --> loop over different values of k and find the most accurate one
#k is ideally an uneven value

k_values = [k for k in range (1, 30, 2)]
#k_values = [13]
fold_results = [] #stores the results of the different k
scores = []


sc = StandardScaler()
X = sc.fit_transform(X_encoded_sampled)

#perform KNN on different k to find the most optimal k
for k in k_values:
    print(k)
    knn = KNeighborsClassifier(n_neighbors=k)
    score = cross_val_score(knn, X, y_sampled, cv=5)
    scores.append(np.mean(score))
print("the most optimal value for k is k = ", np.argmax(scores)) #tested up to 1000 --> above k = 13, the values do not further improve 
sns.lineplot(x = k_values, y = scores, marker = 'o')
# Set labels and title for the elbow plot
axs[1].set_xlabel('Number of Neighbours (k)')
axs[1].set_ylabel('Accuracy Score')
axs[1].set_title('Accuracy Scores for k with Feature Selection')


#use k = 13

# loop over every of the n = 5 splits
for train_index, test_index in skf.split(X_encoded_sampled, y_sampled):

    #get the training and test data fold
    X_test  = X_encoded_sampled.iloc[test_index]
    y_test  = y_sampled.iloc[test_index]
    X_train = X_encoded_sampled.iloc[train_index]
    y_train = y_sampled.iloc[train_index]


    # Standardize features (only numerical features)
    
    X_train_sc = sc.fit_transform(X_train)
    X_test_sc  = sc.transform(X_test)
    

    #train KNN model 
    knn = KNeighborsClassifier(n_neighbors=13) #the optimal k is 13
    knn.fit(X_train_sc, y_train)
    y_test_pred = knn.predict(X_test)
    
    #evaluation for k = 5
    eval_metrics = evaluation_metrics(knn, y_test, X_test_sc, axs[0],legend_entry=str(fold))

    df_performance.loc[len(df_performance)-1,:] = [fold,'KNN']+eval_metrics
    #add the result of the current fold to the list of folds
    
    # increase counter for folds
    fold += 1



# Make the plot pretty
axs[0].set_xlabel('False positive rate (FPR)')
axs[0].set_ylabel('True positive rate (TPR)')
add_identity(axs[0], color="r", ls="--", label='random\nclassifier')
axs[0].legend()
axs[0].grid(True)


axs[0].title.set_text('ROC Curve for KNN without Feature Selection')

plt.tight_layout()

# Save the plot as an image
if feature_selection == True: #depending on which program is run
    plt.savefig('../output/roc_curves_withoutfeatureselection.png')

plt.savefig('../output/roc_curves.png')

# Display the plot
plt.show()

print(df_performance.groupby(by = 'clf').agg(['mean']).mean(axis=0))

